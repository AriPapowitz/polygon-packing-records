"""GPU-batched polygon packer: thousands of simultaneous anneal restarts in JAX.

The whole search runs on-device with a leading batch axis:
  - penalty: vectorized SAT overlap + container violation (same math as
    polygon_packer.py / packer_jax.py, verified equivalent to 8e-16)
  - optimizer: natively-batched L-BFGS (two-loop recursion + Armijo
    backtracking, per-instance convergence masks)
  - anneal: per-instance shrink schedule with random-kick rescue (the batched
    equivalent of the original's basinhopping), instances retire independently

Workflow: run big batches here (GPU, float32 by default on consumer cards),
then certify survivors on CPU with validate_packing.py --polish --squeeze.

Usage:
    python packer_gpu.py 22 3 6 --batch 2048 --waves 4          # GPU exploration
    python packer_gpu.py 8 3 6 --batch 16 --waves 1 --x64      # CPU smoke test
Outputs {n}_{nsi}_in_{nsc}_gpu.json (+ _top{k} variants) for validate_packing.py.
"""

import argparse
import json
import os
import time

import numpy as np

arg_parser = argparse.ArgumentParser()
arg_parser.add_argument("inner_polygons", type=int)
arg_parser.add_argument("inner_sides", type=int)
arg_parser.add_argument("container_sides", type=int)
arg_parser.add_argument("--batch", type=int, default=2048, help="Restarts per wave (GPU-resident)")
arg_parser.add_argument("--waves", type=int, default=4, help="Number of waves (batches) to run")
arg_parser.add_argument("--tolerance", type=float, default=None,
                        help="Penalty acceptance (default 1e-8 for x64, 3e-8 for f32)")
arg_parser.add_argument("--finalstep", type=float, default=0.0001)
arg_parser.add_argument("--kicks", type=int, default=10, help="Random-kick rescues before an instance retires")
arg_parser.add_argument("--kick-size", type=float, default=0.1)
arg_parser.add_argument("--lbfgs-iters", type=int, default=250, help="Max L-BFGS iterations per shrink step")
arg_parser.add_argument("--max-outer", type=int, default=8000, help="Safety cap on shrink steps per wave")
arg_parser.add_argument("--seed0", type=int, default=0)
arg_parser.add_argument("--save-top", type=int, default=3, help="Save the k best packings per run")
arg_parser.add_argument("--x64", action="store_true", help="float64 (A100/H100/CPU); default float32")
args = arg_parser.parse_args()

import jax
if args.x64:
    jax.config.update("jax_enable_x64", True)
import jax.numpy as jnp

DTYPE = jnp.float64 if args.x64 else jnp.float32
TOL = args.tolerance if args.tolerance is not None else (1e-8 if args.x64 else 3e-8)

N = args.inner_polygons
nsi = args.inner_sides
nsc = args.container_sides
D = N * 3
final_step = args.finalstep

# ---------------------------------------------------------------- geometry
inner_angles = np.linspace(0, 2 * np.pi, nsi, endpoint=False)
UNIT_VERTICES = jnp.asarray(np.column_stack((np.cos(inner_angles), np.sin(inner_angles))), dtype=DTYPE)
UNIT_NORMALS = jnp.asarray(np.column_stack((np.cos(inner_angles + np.pi / nsi), np.sin(inner_angles + np.pi / nsi))), dtype=DTYPE)
cont_angles = np.linspace(0, 2 * np.pi, nsc, endpoint=False)
CONT_NORMALS = jnp.asarray(np.column_stack((np.cos(cont_angles + np.pi / nsc), np.sin(cont_angles + np.pi / nsc))), dtype=DTYPE)
CONT_APOTHEM = float(np.cos(np.pi / nsc))
PAIR_I, PAIR_J = np.triu_indices(N, k=1)
LOWEST_S = float(np.sqrt(N * (nsi / 2 * np.sin(2 * np.pi / nsi)) / (nsc / 2 * np.sin(2 * np.pi / nsc))))
RATIO = float(np.sin(np.pi / nsc) / np.sin(np.pi / nsi))  # side ratio = S * RATIO


def penalty(x, S):
    """Penalty for one instance. x: (D,), S: scalar. Batched via vmap."""
    v = x.reshape(N, 3)
    xy, a = v[:, :2], v[:, 2]
    cos_a, sin_a = jnp.cos(a), jnp.sin(a)
    rot = jnp.stack([jnp.stack([cos_a, -sin_a], -1), jnp.stack([sin_a, cos_a], -1)], -2)
    verts = jnp.einsum("nij,vj->nvi", rot, UNIT_VERTICES) + xy[:, None, :]
    normals = jnp.einsum("nij,vj->nvi", rot, UNIT_NORMALS)
    proj_wall = jnp.einsum("nvi,ci->nvc", verts, CONT_NORMALS)
    pen = jnp.sum(jnp.maximum(proj_wall - CONT_APOTHEM * S, 0.0) ** 2)
    axes = jnp.concatenate([normals[PAIR_I], normals[PAIR_J]], axis=1)
    proj_i = jnp.einsum("pvi,pai->pav", verts[PAIR_I], axes)
    proj_j = jnp.einsum("pvi,pai->pav", verts[PAIR_J], axes)
    overlap = (jnp.minimum(proj_i.max(-1), proj_j.max(-1))
               - jnp.maximum(proj_i.min(-1), proj_j.min(-1)))
    pen += jnp.sum(jnp.maximum(overlap.min(-1), 0.0) ** 2)
    return pen


batch_value_and_grad = jax.vmap(jax.value_and_grad(penalty), in_axes=(0, 0))

# ---------------------------------------------------------------- batched L-BFGS
M_HIST = 8
C1 = 1e-4
GTOL = 1e-12


def batched_lbfgs(x, S, max_iters):
    """Minimize penalty for every instance simultaneously. x: (B,D), S: (B,)."""
    B = x.shape[0]
    f, g = batch_value_and_grad(x, S)
    state = {
        "x": x, "f": f, "g": g,
        "s_hist": jnp.zeros((M_HIST, B, D), DTYPE),
        "y_hist": jnp.zeros((M_HIST, B, D), DTYPE),
        "rho": jnp.zeros((M_HIST, B), DTYPE),
        "head": jnp.array(0, jnp.int32),          # circular-buffer write index
        "active": jnp.ones((B,), bool),
        "it": jnp.array(0, jnp.int32),
    }

    def direction(state):
        """Two-loop recursion, batched. Zero-rho pairs are automatic no-ops."""
        q = state["g"]
        alphas = []
        for k in range(M_HIST):
            idx = (state["head"] - 1 - k) % M_HIST
            s_k, y_k, rho_k = state["s_hist"][idx], state["y_hist"][idx], state["rho"][idx]
            alpha = rho_k * jnp.einsum("bd,bd->b", s_k, q)
            q = q - alpha[:, None] * y_k
            alphas.append((idx, alpha))
        idx_last = (state["head"] - 1) % M_HIST
        sy = jnp.einsum("bd,bd->b", state["s_hist"][idx_last], state["y_hist"][idx_last])
        yy = jnp.einsum("bd,bd->b", state["y_hist"][idx_last], state["y_hist"][idx_last])
        gamma = jnp.where(yy > 0, sy / jnp.maximum(yy, 1e-30), 1.0)
        r = jnp.clip(gamma, 1e-4, 1e4)[:, None] * q
        for idx, alpha in reversed(alphas):
            s_k, y_k, rho_k = state["s_hist"][idx], state["y_hist"][idx], state["rho"][idx]
            beta = rho_k * jnp.einsum("bd,bd->b", y_k, r)
            r = r + (alpha - beta)[:, None] * s_k
        d = -r
        # descent safeguard: fall back to steepest descent where needed
        gd = jnp.einsum("bd,bd->b", state["g"], d)
        bad = gd >= 0
        d = jnp.where(bad[:, None], -state["g"], d)
        gd = jnp.where(bad, -jnp.einsum("bd,bd->b", state["g"], state["g"]), gd)
        return d, gd

    def body(state):
        d, gd = direction(state)
        # Armijo backtracking, batched: find per-instance step by halving
        t = jnp.ones((state["x"].shape[0],), DTYPE)
        accepted = jnp.zeros_like(state["active"])
        best_t = jnp.zeros_like(t)

        def ls_body(j, carry):
            t, accepted, best_t = carry
            f_new, _ = batch_value_and_grad(state["x"] + t[:, None] * d, S)
            ok = f_new <= state["f"] + C1 * t * gd
            newly = ok & ~accepted
            best_t = jnp.where(newly, t, best_t)
            accepted = accepted | ok
            t = jnp.where(accepted, t, t * 0.5)
            return t, accepted, best_t

        t, accepted, best_t = jax.lax.fori_loop(0, 25, ls_body, (t, accepted, best_t))
        step = jnp.where(accepted, best_t, 0.0)

        x_new = state["x"] + step[:, None] * d
        f_new, g_new = batch_value_and_grad(x_new, S)
        improved = (f_new < state["f"]) & state["active"]
        x_next = jnp.where(improved[:, None], x_new, state["x"])
        f_next = jnp.where(improved, f_new, state["f"])
        g_next = jnp.where(improved[:, None], g_new, state["g"])

        # history update (only meaningful where improved; rho=0 disables elsewhere)
        s_vec = x_next - state["x"]
        y_vec = g_next - state["g"]
        sy = jnp.einsum("bd,bd->b", s_vec, y_vec)
        rho_new = jnp.where(improved & (sy > 1e-30), 1.0 / jnp.maximum(sy, 1e-30), 0.0)
        head = state["head"]
        s_hist = state["s_hist"].at[head].set(s_vec)
        y_hist = state["y_hist"].at[head].set(y_vec)
        rho = state["rho"].at[head].set(rho_new)

        gmax = jnp.max(jnp.abs(g_next), axis=1)
        still = improved & (gmax > GTOL) & (f_next > 0)
        return {
            "x": x_next, "f": f_next, "g": g_next,
            "s_hist": s_hist, "y_hist": y_hist, "rho": rho,
            "head": (head + 1) % M_HIST,
            "active": state["active"] & still,
            "it": state["it"] + 1,
        }

    def cond(state):
        return jnp.any(state["active"]) & (state["it"] < max_iters)

    state = jax.lax.while_loop(cond, body, state)
    return state["x"], state["f"]


# ---------------------------------------------------------------- batched anneal wave

def init_batch(key, B):
    """Half uniform-random, half jittered-grid starts (mirrors the CPU packer)."""
    k1, k2, k3, k4, k5 = jax.random.split(key, 5)
    S0 = LOWEST_S * (2.0 + 2.0 * jax.random.uniform(k1, (B,), DTYPE))
    xy = jax.random.uniform(k2, (B, N, 2), DTYPE, -0.5, 0.5) * S0[:, None, None]
    ang = jax.random.uniform(k3, (B, N), DTYPE, 0.0, 2 * np.pi)

    side = int(np.ceil(np.sqrt(N)))
    lin = np.linspace(-0.45, 0.45, side)
    gx, gy = np.meshgrid(lin, lin)
    grid = jnp.asarray(np.column_stack((gx.ravel(), gy.ravel()))[:N], DTYPE)   # (N,2)
    grid_xy = grid[None, :, :] * S0[:, None, None]
    use_grid = jax.random.uniform(k4, (B,), DTYPE) < 0.5
    xy = jnp.where(use_grid[:, None, None], grid_xy, xy)
    xy = xy + jax.random.normal(k5, xy.shape, DTYPE) * 0.01

    x = jnp.concatenate([xy, ang[:, :, None]], axis=2).reshape(B, D)
    return x, S0


def wave(key, B):
    """One full wave: B instances annealed until all retire. Returns (S, x) per instance."""
    x, S = init_batch(key, B)
    state = {
        "x": x, "S": S,
        "initial_S": S,
        "best_x": x, "best_S": jnp.full((B,), jnp.inf, DTYPE),
        "kicks_left": jnp.full((B,), args.kicks, jnp.int32),
        "done": jnp.zeros((B,), bool),
        "key": key,
        "outer": jnp.array(0, jnp.int32),
    }

    def body(state):
        x_opt, pen = batched_lbfgs(state["x"], state["S"], args.lbfgs_iters)
        ok = (pen < TOL) & ~state["done"]

        span = jnp.maximum(state["initial_S"] - LOWEST_S, 1e-9)
        mult = 1 - final_step - (state["S"] - LOWEST_S) * (0.01 - final_step) / span
        mult = jnp.minimum(mult, 1 - final_step)  # guard: always shrink

        # success: record best, shrink, refill kicks
        best_S = jnp.where(ok, state["S"], state["best_S"])
        best_x = jnp.where(ok[:, None], x_opt, state["best_x"])
        S_next = jnp.where(ok, state["S"] * mult, state["S"])
        x_next = jnp.where(ok[:, None], x_opt * mult[:, None], x_opt)
        kicks = jnp.where(ok, args.kicks, state["kicks_left"])

        # failure with kicks left: random perturbation, retry at same S
        key, sub = jax.random.split(state["key"])
        noise = jax.random.normal(sub, x_opt.shape, DTYPE) * args.kick_size
        failed = ~ok & ~state["done"]
        kick = failed & (state["kicks_left"] > 0)
        x_next = jnp.where(kick[:, None], x_opt + noise, x_next)
        kicks = jnp.where(kick, kicks - 1, kicks)

        # failure with no kicks: retire
        done = state["done"] | (failed & (state["kicks_left"] <= 0))

        return {
            "x": x_next, "S": S_next, "initial_S": state["initial_S"],
            "best_x": best_x, "best_S": best_S,
            "kicks_left": kicks, "done": done, "key": key,
            "outer": state["outer"] + 1,
        }

    def cond(state):
        return jnp.any(~state["done"]) & (state["outer"] < args.max_outer)

    state = jax.lax.while_loop(cond, body, state)
    return state["best_S"], state["best_x"]


wave_jit = jax.jit(wave, static_argnums=(1,))


def save_solution(stem, S, x):
    out = f"{stem}.json"
    file_i = 1
    while os.path.exists(out):
        out = f"{stem}_({file_i}).json"
        file_i += 1
    with open(out, "w") as f:
        json.dump({
            "inner_polygons": N, "inner_sides": nsi, "container_sides": nsc,
            "container_circumradius": float(S),
            "side_length": float(S) * RATIO,
            "placements": [{"x": float(x[i * 3]), "y": float(x[i * 3 + 1]),
                            "angle": float(x[i * 3 + 2])} for i in range(N)],
        }, f, indent=2)
    return out


if __name__ == "__main__":
    print(f"device: {jax.devices()[0]}  dtype: {DTYPE.__name__}  tol: {TOL:g}")
    print(f"{N} {nsi}-gons in a {nsc}-gon; lower bound S = {LOWEST_S:.6f} (ratio {LOWEST_S * RATIO:.6f})")

    t0 = time.perf_counter()
    all_S, all_x = [], []
    for w in range(args.waves):
        key = jax.random.PRNGKey(args.seed0 + w)
        best_S, best_x = wave_jit(key, args.batch)
        best_S, best_x = np.asarray(best_S), np.asarray(best_x)
        valid = np.isfinite(best_S)
        all_S.append(best_S[valid])
        all_x.append(best_x[valid])
        wave_best = best_S[valid].min() if valid.any() else float("inf")
        print(f"wave {w}: {valid.sum()}/{args.batch} valid, best ratio = {wave_best * RATIO:.9f} "
              f"({time.perf_counter() - t0:.1f}s total)", flush=True)

    S_all = np.concatenate(all_S)
    x_all = np.concatenate(all_x)
    order = np.argsort(S_all)
    print(f"TOTAL: {len(S_all)} valid restarts in {time.perf_counter() - t0:.1f}s")
    print("Best ratio:", S_all[order[0]] * RATIO)
    for rank in range(min(args.save_top, len(order))):
        i = order[rank]
        out = save_solution(f"{N}_{nsi}_in_{nsc}_gpu_top{rank + 1}", S_all[i], x_all[i])
        print(f"  #{rank + 1}: ratio {S_all[i] * RATIO:.9f} -> {out}")
